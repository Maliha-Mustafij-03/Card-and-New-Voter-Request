<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Smart Card & New Voter Request Management System.IDEA Phase-2.All rights reserved.</p>
                                </div>
                            </div>
                        </div>