<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
        
                   <h4>Smart Card & New Voter Request Management System</h4>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="dashboard.php"  style="color: blue">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>

     <li>
                            <a href="requestors-form.php"  style="color: blue">
                                <i class="fa fa-user"></i>New Smartcard Request Entry</a>
                        </li>
   <li>
                            <a href="manage-newrequestor.php"  style="color: blue">
                                <i class="fa fa-users"></i>Manage SmartCard Request</a>
                        </li>

                         <li>
                            <a href="bwdates-reports.php"  style="color: blue">
                                <i class="fas fa-copy"></i>Report of Smartcard Request</a>
                        </li>  
     <li>
                            <a href="new_voter_req.php"  style="color: blue">
                                <i class="fa fa-user"></i>New Voter Request Entry</a>
                        </li>  
 <li>
                            <a href="manage-newvoter.php"  style="color: blue">
                                <i class="fa fa-users"></i>Manage New Voter </a>
                        </li>  
                      
                      
                       <li>
                            <a href="bwdates-newvoter-reports.php"  style="color: blue">
                                <i class="fas fa-copy"></i> Report of New Voter Request</a>
                        </li> 
                    </ul>
                </nav>
            </div>
        </aside>