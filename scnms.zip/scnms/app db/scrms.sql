-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2023 at 10:51 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scrms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(5) NOT NULL,
  `AdminName` varchar(45) DEFAULT NULL,
  `UserName` char(45) DEFAULT NULL,
  `MobileNumber` varchar(125) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Idea -2', 'smartcard', '01684422703', 'maliha1218@gmail.com', '202cb962ac59075b964b07152d234b70', '2023-09-01 06:26:14');

-- --------------------------------------------------------

--
-- Table structure for table `tblnewvoter`
--

CREATE TABLE `tblnewvoter` (
  `Sl` int(125) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `NIDFN` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Reference` varchar(255) NOT NULL,
  `Comments` varchar(255) NOT NULL,
  `Current_Condition` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblnewvoter`
--

INSERT INTO `tblnewvoter` (`Sl`, `Name`, `NIDFN`, `Date`, `Reference`, `Comments`, `Current_Condition`) VALUES
(2, 'babar ali', '434554654654564', '2023-10-15', 'demo', 'bbknbk', 'done'),
(3, 'maliha', '434554654654564', '2023-10-16', 'bg akter', 'ok', 'df'),
(5, 'sadia', '3535', '2023-10-16', 'try', 'asdas', 'asds');

-- --------------------------------------------------------

--
-- Table structure for table `tblvisitor`
--

CREATE TABLE `tblvisitor` (
  `ID` int(125) NOT NULL,
  `EnterDate` date DEFAULT NULL,
  `PinNo` varchar(125) DEFAULT NULL,
  `NewNid` varchar(125) DEFAULT NULL,
  `Name` varchar(120) DEFAULT NULL,
  `PrintReprint` varchar(250) NOT NULL DEFAULT '''NULL''',
  `Transaction` varchar(120) NOT NULL DEFAULT 'NULL',
  `RefName` varchar(120) DEFAULT NULL,
  `Destination` varchar(120) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblvisitor`
--

INSERT INTO `tblvisitor` (`ID`, `EnterDate`, `PinNo`, `NewNid`, `Name`, `PrintReprint`, `Transaction`, `RefName`, `Destination`, `remark`) VALUES
(35, '2023-09-03', '43453', '55456', 'jahanara akhtar', 'reprint', '2464', 'dit', 'dhaka', NULL),
(40, '2023-09-07', '23', '23', 'sarmin sultana', 'print', '3456', 'dit', 'dhk', NULL),
(43, '2022-09-04', '2147483647', '2147483647', 'jahan', 'Reprint', '2233445566', 'dit', 'Shylet', NULL),
(45, '2023-08-30', '344534', '453645645', 'yasmin akhter', 'Reprint', 'rerx456ty789', 'dit', 'fdfgv', NULL),
(46, '2023-09-01', '654647', '2147483647', 'maliha mustafij b', 'Reprint', 'tx34567ty908jk56', 'dit', 'ctg', 'job done'),
(47, NULL, '34567890', '4567890', 'sheikh saiful islam', 'Reprint', 'ty567xz34567l', 'dit', 'dhk', NULL),
(48, '2023-09-04', '45678', '56789', 'sadika', 'Reprint', 'ty678j9n', 'dit', 'dhk', NULL),
(49, '2023-09-04', '35665765', '564564', 'maliha', 'Reprint', 'trtytr', 'dsfdf', 'dhk', 'job done'),
(50, '2023-09-04', '555', '767567', 'peter', 'Reprint', 'g', 'f', 'g', NULL),
(51, '2023-09-04', '6', '8768', 'mmm', 'Reprint', '777', 'dit', 'dhk', NULL),
(52, '2023-09-04', '23', '23', 'aaa', 'Print', '1234', 'aaa', '4', NULL),
(53, '2023-09-04', '23', '23', 'dddd', 'Print', '12345', 'sss', 'sdf', NULL),
(54, '2023-09-04', '12345', '642688564', 'maliha', 'Reprint', 'dfgdf', 'dit', 'dhk', NULL),
(55, '2023-09-04', '2345', '346', 'm', 'Reprint', 'rwr', 'g', 't', NULL),
(56, '2023-09-04', '3', '3', 'b', 'Reprint', 't', 'd', 'r', NULL),
(57, '2023-09-04', '3456', '789', 'jih', 'Reprint', 'uhguibi', 'hjguig', 'dhk', NULL),
(58, '2023-09-04', '3456', '789', 'jih', 'Reprint', 'uhguibi', 'hjguig', 'dhk', NULL),
(59, '2023-10-06', '4', '2', 'm', 'Reprint', 'r', 'd', 'd', NULL),
(60, '2023-09-04', '6', '2', 'd', 'Reprint', 'd', 'd', 'a', NULL),
(61, '2023-09-29', '4', '2', 'r', 'Reprint', 'e', '3', 'e', NULL),
(62, '2023-09-04', '3', '3', 'm', 'Reprint', 'r', 'd', 'd', NULL),
(63, '2023-09-04', '3', '23', 'r', 'Reprint', 't6', 't', 'dhk', NULL),
(64, '2023-09-04', '12345', '2147483647', 'forkan miah', 'Reprint', 'terter', 'dit', 'dhk', NULL),
(65, '2023-09-04', '12345', '2345688', 'yasmin bhuiya', 'Reprint', '434535tyu', 'director it', 'Dhaka', 'job completed'),
(66, '2023-09-04', '3212343', '23', 'tohura', 'Reprint', '434535', 'director it', 'syhlet', NULL),
(67, '2023-10-15', '12345', '6426885643', 'maliha', 'Wrong_Input', 'sdfsfs32434', 'dit', 'dhk', NULL),
(68, '2023-10-15', '12345', '6426885643', 'maliha', 'Wrong_Input', 'fdfgdfg45656756', 'dit', 'dhk', NULL),
(69, '2023-10-15', '12345', '6426885643', 'maliha', 'Reprint', 'ffffd', 'dit', 'syl', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblnewvoter`
--
ALTER TABLE `tblnewvoter`
  ADD PRIMARY KEY (`Sl`);

--
-- Indexes for table `tblvisitor`
--
ALTER TABLE `tblvisitor`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblnewvoter`
--
ALTER TABLE `tblnewvoter`
  MODIFY `Sl` int(125) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblvisitor`
--
ALTER TABLE `tblvisitor`
  MODIFY `ID` int(125) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
